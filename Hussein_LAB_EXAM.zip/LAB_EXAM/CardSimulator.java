
/**
 * Simulation class for CardStack class
 * 
 * @author Zainab Hussein
 * @version 4-4-2017
 */
public class CardSimulator
{
    // instance variables - replace the example below with your own
    
    /**
     * Constructor for objects of class CardSimulator
     */
    public CardSimulator(){}
    
    public static void main(String[] args)
    {
        String fileName = "datIn.txt";
        CardStack list = new CardStack();
        list.read( fileName );
        
        //player 1
        list.draw();
        
        //player 1
        list.draw();
        
        //check is stack empry
        list.isEmpty();
    }
}
