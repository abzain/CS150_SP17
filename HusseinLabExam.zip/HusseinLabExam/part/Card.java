
/**
 * Class Card - card game
 * 
 * @author Zainab Hussein
 * @version 4-4-2017
 */
public class Card implements Comparable<Card>
{
    // instance variables - replace the example below with your own
    public int number;
    public String character;

    /**
     * Constructor for objects of class Card
     */
    public Card( String myChar, int myNum )
    {
        // initialise instance variables
        this.character = myChar;
        this.number = myNum;
    }

     /**
     * compareTo method to make Card class comparable
     * 
     * @param - number, character
     * @return ordering of contacts by:
     * 1.IC -> equal num, C<D<H<S -> by number
     */
    @Override
    public int compareTo( Card c )
    {
        Integer num1 = new Integer(this.number);
        Integer num2 = new Integer(c.number);
        Integer one = new Integer(1);
        String C = new String();
        String H = new String();
        String S = new String();
        String D = new String();
        
        if( num1 == one && this.character == C ){
            if( num1.equals(num2)){
                if( this.character.equals(S)){
                    if( this.character.equals(H)){
                        if( this.character.equals(D)){
                            if( this.character.equals(C)){
                                if( num1.equals(13)){
                                     if( num1.equals(12)){
                                          if( num1.equals(11)){
                                               if( num1.equals(10)){
                                                    if( num1.equals(9)){
                                                         if( num1.equals(8)){
                                                              if( num1.equals(7)){
                                                                   if( num1.equals(6)){
                                                                       if( num1.equals(5)){
                                                                           if( num1.equals(4)){
                                                                               if( num1.equals(3)){
                                                                                   if( num1.equals(2)){
                                                                                       return num1.compareTo(1);
                                                                                    }
                                                                                    else{
                                                                                        return num1.compareTo(2);
                                                                                    }
                                                                                }
                                                                                else{
                                                                                    return num1.compareTo(3);
                                                                                }
                                                                            }
                                                                            else{
                                                                                return num1.compareTo(4);
                                                                           }
                                                                        }
                                                                        else{
                                                                            return num1.compareTo(5);
                                                                        }
                                                                    }
                                                                   else{
                                                                       return num1.compareTo(6);
                                                                   }
                                                              }
                                                              else{
                                                                  return num1.compareTo(7);
                                                                }
                                                         }
                                                         else{
                                                            return num1.compareTo(8);
                                                         }
                                                    }         
                                                    else{
                                                        return num1.compareTo(9);
                                                    }
                                                }
                                                else{
                                                    return num1.compareTo(10);
                                               }
                                          }
                                          else{
                                              return num1.compareTo(11);
                                          }
                                     }
                                     else{
                                        return num1.compareTo(12);
                                    }
                                }
                                else{
                                    return num1.compareTo(13);
                                }
                            }
                            else{
                                return this.character.compareTo(C);
                            }
                        }
                        else{
                            return this.character.compareTo(D);
                        }
                    }
                    else{
                        return this.character.compareTo(H);
                    }
                }
                else{
                    return this.character.compareTo(S);
                }
            }
            else{
                return num1.compareTo(num2);
            }
        }
        else{
            return ( num1.compareTo(one) & this.character.compareTo(C) );
        }
    }
}
