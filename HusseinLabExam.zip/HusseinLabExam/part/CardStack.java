import java.util.*;
import java.io.*;
/**
 * class CardStack - stores cards in a stack
 * 
 * @author Zainab Hussein
 * @version 4-4-2017
 */
public class CardStack
{
    // instance variables - replace the example below with your own
    public Stack<Card> st;
    Card k = new Card( null, 0 );

    /**
     * Constructor for objects of class CardStack
     */
    public CardStack()
    {
        // initialise instance variables
        st = new Stack<Card>();
    }

    /**
     * add cards to stack method
     */
    public Card add( Card e )
    {
        return st.push( e );
    }
    
    /** 
     * read input file containing cards method
     */
    public void read( String fileName ){
        File inFile = new File( fileName );
        
        //create structure to store values for comparison
        ArrayList<String> chars = new ArrayList<String>();
        ArrayList<Integer> nums = new ArrayList<Integer>();
        try{
            Scanner in_file = new Scanner( inFile );
            while(in_file.hasNextLine()) 
            {
               //taking one line(class of items) as a case, solve it, and go to next
               String whole_class = in_file.nextLine();
               Scanner in_line = new Scanner(whole_class);
               
               if(in_line.hasNext()){
                   //get the class name first 
                   String char_class = in_line.next();
                   int num_item = in_line.nextInt();

                   chars.add( char_class );
                   nums.add( num_item );
               }
               in_line.close();
            }
             in_file.close();
         }
         catch( Exception e ) { 
                System.out.println(e);
        }
        
        for( int i = 0; i< chars.size(); i++ ){
            k.character = chars.get(i);
        }
        for( int i = 0; i< nums.size(); i++ ){
            k.number = nums.get(i);
        }
        
    }
    
    /**
     * draw and return a card from the stack method
     */
    public Card draw()
    {
        return st.pop();
    }
    
    /**
     * isEmpty method
     */
    public boolean isEmpty()
    {
        return st.empty();
    }
}
